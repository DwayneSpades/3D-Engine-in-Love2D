function love.conf(t)
  t.console = false
  t.window.width=600
  t.window.height=600
  
  
  --t.window.depth=24
  t.identity = '3D Cube Demo'  
  
   
end

