~Preston Adams~
Just run 3D Deer Demo.exe. You can move and spin a deer model around. 

There's a second deer model in the demo to show the z-buffer sorting.

3D Engines Current Features:

- matrix & point classes

- matrix math functionality

- perspective projection of 3D shapes

- loading and parsing of .obj file data (vertices, lines, and UV Coordinates)

- able to display textures on 3d models

- simple z-buffer that sorts the drawing order of models

- backface culling 